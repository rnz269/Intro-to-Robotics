int desiredPower_B;
int currentPower_B;
int desiredPower_C;
int currentPower_C;

task motorBControlTask
{
   while(desiredPower_B-currentPower_B!=0)
   {
     if(desiredPower_B>currentPower_B)
     {
        currentPower_B++;
     }
     else
     {
        currentPower_B--;
     }
     setMotorSpeed(motorB, currentPower_B);
     sleep(500);
   }
}
task motorCControlTask
{
  while(desiredPower_C-currentPower_C!=0)
   {
     if(desiredPower_C>currentPower_C)
     {
        currentPower_C++;
     }
     else
     {
        currentPower_C--;
     }
     setMotorSpeed(motorC, currentPower_C);
     sleep(500);
   }
}


task main()
{
  currentPower_B = 0;
  desiredPower_B = 67;
  currentPower_C = 0;
  desiredPower_C = -80;
   startTask(motorBControlTask);
   startTask(motorCControlTask);
   while(true)
   {
   displayBigTextLine(3, "%d/%d", currentPower_B, desiredPower_B);
   displayBigTextLine(5, "%d/%d", currentPower_C, desiredPower_C);
   sleep(500);
   }
}
